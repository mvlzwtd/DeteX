#! /usr/bin/perl -w

use strict;
use File::Basename;
use Cwd 'abs_path';
use Getopt::Long;

#############################################################################################
########################## Define and Introduce patameters ##################################
#############################################################################################

###################################  Introduction for use ###################################
my $usage=<<USAGE;

Usage:

Copyright    : Marvelbio
Program Name : DeteX.pl
Version      : Version 4.0
Author       : zhangzhenzhen
Contact      : zzz\@marvelbio.com
Last Modified: 2021/10/13
Description  : The function of this program is to call somatic snv and indel from alignment 
               data in bam format of cancer and normal samples.One alignment data is required 
			   at least.If cancer and normal samples are existing in the same time,this program 
			   is to call somatic variation,else it is to call single variation in one sample.

Example      : To call somatic variation:
			   perl DeteX.pl -nb control.bam -cb case.bam -od outdir -rd refdir -bd target.bed -sp samplename
	       
	           To call single variation: 
	           perl DeteX.pl -cb case.bam -od outdir -rd refdir -bd target.bed -sp samplename

Usage        : perl DeteX.pl -nb control.bam -cb case.bam -od outdir -rd refdir -bd target.bed -sp samplename [options]

Options :
input options :
 -nb,--control-bam <file>                the alignment data file in bam format of normal sample
 -cb,--case-bam <file>                   the alignment data file in bam format of cancer sample
 -rd,--reference-dir <dir name>          the dir of all the chromosome sequences file in fasta format
 -bd,--bed <file>                        the region to call snv/indel in bed format
 -pd,--program-dir <dir name>            the program dir where this program depends on
 -rr,--repeat-region <file>              the repeat region file in bed format
 -rt,--reference-version <String>        assembly version of referrence(hg19 or hg38,default hg19)

output options :
 -od,--outdir <outdir name>              the dir of output file
 -sp,--sample <sample name>              the output sample name 

parameter options :
reads filter options :
 -mn,--max-mismatch-num <INT>            the maximum mismatch number in one read,if more than,the 
										 read is filed (3)
 -mq,--min-map-quality <INT>			 the minimum map quality to call snv and indel(25),if less than,
										 this read is filted.
single sample variation detection options :
 -bq,--min-base-quality-to-call <INT>    the minimum base quality to call snv (13)
 -mm,--mean-map-quality-to-filt <INT>    the mean mutated reads map quality to filt(40),if less than this value,
                                         this variation is filted.
 -de,--min-distance-to-end <INT>         the minimum distance to end (5)
 -me,--min-mean-distance-to-end <INT>    the minimum mean distance to end of all mutated reads (20)
 -fb,--max-freq-read-bias <float>        the maximum probability of more reads in one direction (99%)

single sample snv filt options :
 -vn,--min-var-num <INT>                 the minimum mutated read number in case sample (3)
 -dp,--min-depth-to-call <INT>           the minimum sequencing depth (10)
 -tf,--min-var-frequence <float>         the minimum variation frequence in case sample (1%)
somatic snv detection options :
 -nf,--max-var-frequence <float>         the maximum variation frequence in normal sample (2%)
 -pp,--p-value                           the p value to call somatic variation (5)% 
thread option :
 -tn,--thread-num <INT>                  the thread num (10)

help option :
 -h,--help                              output the help file

USAGE

################################## Defined all variables #################################

## defined input variables
my ($control,$case,$refdir,$bed,$progdir,$repeat,$reftp);

## defined output variables
my ($outdir,$sample);

## defined parameter variables
my ($mn,$vn,$dp,$nf,$bq,$mq,$mm,$tf,$de,$me,$fb,$pp,$tn);

## defined help variables
my ($help);

GetOptions(

    "nb|control-bam:s"                =>\$control,
    "cb|case-bam:s"                   =>\$case,
    "rd|reference-dir:s"              =>\$refdir,
    "bd|bed:s"                        =>\$bed,
    "pd|program-dir:s"                =>\$progdir,
	"rr|repeat-region:s"              =>\$repeat,
	"rt|reference-type:s"             =>\$reftp,

    "od|outdir:s"                     =>\$outdir,
    "sp|sample:s"                     =>\$sample,

    "mn|max-mismatch-num:i"           =>\$mn,
    "vn|min-var-num:i"                =>\$vn,
	"dp|min-depth-to-call:i"          =>\$dp,
    "nf|max-var-frequence:f"          =>\$nf,
    "bq|min-base-quality-to-call:i"   =>\$bq,
    "mq|min-map-quality:i"            =>\$mq,
    "mm|mean-map-quality-to-filt:i"   =>\$mm,
    "tf|min-var-frequence:f"          =>\$tf,
    "de|min-distance-to-end:i"        =>\$de,
    "me|min-mean-distance-to-end:i"   =>\$me,
	"fb|max-freq-read-bias:f"         =>\$fb,
    "pp|fisher-p-value:f"             =>\$pp,
    "tn|thread-num:i"                 =>\$tn,

    "h|help"                          =>\$help,
);

############################# Defined defult value of variables ##############################
 $0=abs_path($0);
 my $pdir=dirname($0);
 $progdir ||= "$pdir/bin";
 $refdir  ||= "$pdir/refdir";
 $repeat  ||= "null";

 $outdir  ||= "./";
# $outdir    = abs_path($outdir);
 $sample  ||= basename($outdir);
 $reftp   ||= "hg19";

 $mn ||= 3;
 $vn ||= 3;
 $dp ||=10;
 $nf ||= 0.02;
 $bq ||= 13;
 $mq ||= 25;
 $mm ||= 40;
 $tf ||= 0.01;
 $de ||= 5;
 $me ||= 20;
 $fb ||= 0.9;
 $pp ||= 0.05;
 $tn ||= 10;

############################# Output instructions ###########################################

## Output the instructions if not defined normal and cancer bam file or input parameter help
 if((!$control and !$case) || $help){
    print "$usage\n";
    exit;
 }

############################### end of part one ##############################################

##############################################################################################
################################ Operate other programs ######################################
##############################################################################################

## defined log file 
## record current time and state and output it into log file
`mkdir -p $outdir/sh`;
open SH,">$outdir/sh/$sample.sh";
print SH "#!/bin/bash\n\n";
print SH "log=$outdir/sh/$sample.sh.log\n";
print SH "err=$outdir/sh/$sample.sh.err\n";
print SH "out=$outdir/sh/$sample.sh.out\n\n";
print SH "date '+%y-%m-%d %H:%M:%S\tstarting analysis' >\$log\n\n";

########################## split bed file based on the number of thread #########################

my $beddir="$outdir/bed";
`mkdir -p $beddir`;
my @line=split(/\s+/,`wc -l $bed`); ## calculate line number of bed file
my $m=int(($line[0]-1)/$tn)+1;          ## calculate line number of one bed file after split
my $row=0;                          ## row number of bed file
my $n=1;                            ## the Q number of output bed file
open BED,"<$bed" or die "Can't open file $bed !";
open OUT,">$outdir/bed/$sample.$n.bed";
my $chr="";
my $chrseq="";
while(<BED>){
    chomp;
    if(($row % $m==0) and ($row>0)){
        close OUT;
        $n++;
        open OUT,">$outdir/bed/$sample.$n.bed";
    }
    my @a=split;
    my $len=$a[2]-$a[1]+2;
	my $start=$a[1]-1;
    my $region=$_;
    if($a[0] ne $chr){
       $chr=$a[0];
       $chrseq="";
       open SEQ,"$refdir/$chr.fa";
	   <SEQ>;
       while(<SEQ>){
           chomp;
           $chrseq.=$_;
       }
       close SEQ;
    }
    my $subseq=substr($chrseq,$start,$len);
    $subseq=uc($subseq);
    print OUT "$region\t$subseq\n";
    $row++;
}
close OUT;
close BED;

########################## Operate the programs in the second module #########################

## base.pl : to output sequencing result of every mutatied position in bed of each sample
## Branches based on sample type

my $state;  ## record current state
my $data;  ## record the return value of system
my $casesam="$sample.case";
my $controlsam="$sample.control";

if(!$control){
    print SH "perl $progdir/Base.pl $case $outdir $casesam $mn $mq $bq $mm $de $me $tn >>\$out 2>>\$err \n\n";
	print SH "date '+%y-%m-%d %H:%M:%S\tStatistic sequencing result of cancer sample is finished' >>\$log\n\n";
}
else{ 
	print SH "perl $progdir/Base.pl $case  $outdir $casesam $mn $mq  $bq $mm $de $me $tn >>\$out 2>>\$err \n\n";
    print SH "date '+%y-%m-%d %H:%M:%S\tStatistic sequencing result of cancer sample is finished' >>\$log\n\n";

	print SH "perl $progdir/Base.pl $control  $outdir $controlsam $mn $mq $bq $mm $de $me $tn >>\$out 2>>\$err \n\n";
	print SH "date '+%y-%m-%d %H:%M:%S\tStatistic sequencing result of control sample is finished' >>\$log\n\n";
}

########################## Operate the programs in the third module ##########################

if(!$control){
	print SH "perl $progdir/SigVarTest.pl $outdir $casesam $fb $tn >>\$out 2>>\$err \n\n";
	print SH "date '+%y-%m-%d %H:%M:%S\tVariation calling of case sample is finished' >>\$log\n\n";
}
else{
	print SH "perl $progdir/SomaticVarTest.pl $outdir $sample $mm $fb $nf $pp $tn >>\$out 2>>\$err \n\n";
	print SH "date '+%y-%m-%d %H:%M:%S\tVariation calling of paired sample is finished' >>\$log\n\n";
}

########################## Operate the programs in the forth module ##########################

if(!$control){
	
	print SH "perl $progdir/SigVarFilt.pl  $outdir $sample $repeat $reftp $vn $dp $tf $tn >>\$out 2>>\$err \n\n";
	print SH "date '+%y-%m-%d %H:%M:%S\tVariation filt of cancer sample is finished' >>\$log\n\n";
}
else{
	
	print SH "perl $progdir/SomaticVarFilt.pl $outdir $sample $repeat $reftp $vn $dp $tf $tn >>\$out 2>>\$err \n\n";
	print SH "date '+%y-%m-%d %H:%M:%S\tVariation filt of paired sample is finished' >>\$log\n\n";
}

close SH;
`sh $outdir/sh/$sample.sh`;
